<?php
namespace ModulesGarden\DomainsReseller\Registrar\KDHOST\Calls;
use ModulesGarden\DomainsReseller\Registrar\KDHOST\Core\Call;

/**
 * Description of TransferDomain
 *
 * @author inbs
 */
class GetRegistrarLock extends Call
{
    public $action = "domains/:domain/lock";
    
    public $type = parent::TYPE_GET;
}