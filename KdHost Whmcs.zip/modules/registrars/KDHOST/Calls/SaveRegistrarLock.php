<?php
namespace ModulesGarden\DomainsReseller\Registrar\KDHOST\Calls;
use ModulesGarden\DomainsReseller\Registrar\KDHOST\Core\Call;

/**
 * Description of TransferDomain
 *
 * @author inbs
 */
class SaveRegistrarLock extends Call
{
    public $action = "domains/:domain/lock";
    
    public $type = parent::TYPE_POST;
}