<?php
namespace ModulesGarden\DomainsReseller\Registrar\KDHOST\Calls;
use ModulesGarden\DomainsReseller\Registrar\KDHOST\Core\Call;

/**
 * Description of TransferDomain
 *
 * @author inbs
 */
class ModifyNameServer extends Call
{
    public $action = "domains/:domain/nameservers/modify";
    
    public $type = parent::TYPE_POST;
}