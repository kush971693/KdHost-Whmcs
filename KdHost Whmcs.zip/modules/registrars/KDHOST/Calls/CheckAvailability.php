<?php
namespace ModulesGarden\DomainsReseller\Registrar\KDHOST\Calls;
use ModulesGarden\DomainsReseller\Registrar\KDHOST\Core\Call;

/**
 * Description of CheckAvailability
 *
 * @author inbs
 */
class CheckAvailability extends Call
{
    public $action = "domains/lookup";
    
    public $type = parent::TYPE_POST;
}