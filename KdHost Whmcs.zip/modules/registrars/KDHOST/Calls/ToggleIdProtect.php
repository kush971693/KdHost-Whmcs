<?php
namespace ModulesGarden\DomainsReseller\Registrar\KDHOST\Calls;
use ModulesGarden\DomainsReseller\Registrar\KDHOST\Core\Call;

/**
 * Description of GetNameServers
 *
 * @author inbs
 */
class ToggleIdProtect extends Call
{
    public $action = "domains/:domain/protectid";
    
    public $type = parent::TYPE_POST;
}